using System;
public interface IDibujante
{
    void DibujarCirculo(int radio);
    void DibujarRectangulo(int ancho, int alto);
    
}
