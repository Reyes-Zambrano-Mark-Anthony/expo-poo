﻿class Program
{
    static void Main()
    {
        IDibujante dibujanteColor = new DibujanteColor();
        colorRojo colorRojo = new colorRojo();
        IDibujante dibujanteBlancoNegro = new DibujanteBlancoYNegro();

        Forma circuloColorRojo = new Circulo(5,"colorRojo", dibujanteColor);
        Forma rectanguloBlancoNegro = new Rectangulo(4, 6, dibujanteBlancoNegro);

        circuloColorRojo.Dibujar();
        rectanguloBlancoNegro.Dibujar();
    }
}