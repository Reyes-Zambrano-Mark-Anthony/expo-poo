public interface IColor
{
    void AplicarColor();
}
public class colorRojo
{
    public void AplicarColor()
    {
        Console.WriteLine("rojo");
    }
}
