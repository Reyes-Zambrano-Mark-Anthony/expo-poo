using System.Drawing;

public class Circulo : Forma
{
    private int radio;
    
    public Circulo(int radio, string color, IDibujante dibujante) : base(dibujante)
    {
        this.radio = radio;
    }

    public override void Dibujar()
    {
        dibujante.DibujarCirculo(radio);
    }
}