public abstract class Forma
{
    protected IDibujante dibujante;

    public Forma(IDibujante dibujante)
    {
        this.dibujante = dibujante;
    }

    public abstract void Dibujar();
}